# Capturas reais — Alien Client / Forge 1.8.9

Nova execução aprovada: 54 verificações gráficas, 16 PNGs originais; 46 testes JUnit executados novamente, zero falhas/erros/ignorados.

Minecraft Java 1.8.9, Forge 11.15.1.2318, Java 8, Xvfb e OpenGL por software. As imagens vieram do framebuffer real via ScreenShotHelper; não foram geradas por IA, desenhadas ou retocadas. Resolução: 854 × 480.

## Imagens solicitadas

1. Menu inicial: screenshots/01-title.png
2. Menu de módulos dentro do mundo: screenshots/09c-alien-menu-inside-world.png
3. Editor de cosméticos 3D: screenshots/10-cosmetic-live-player-preview.png
4. Céu/clima dentro do mundo: screenshots/09d-world-studio-inside-world.png; panorama importado: screenshots/12-imported-skybox-live-world.png
5. HUD em mundo carregado: screenshots/09b-custom-sky-minimum-distance.png

## Comandos realmente executados

```bash
cd /workspace/Alien-Client
env -u DISPLAY ALIEN_TOOLS_DIR=/workspace/.alien-tools ./scripts/smoke-client.sh
ALIEN_TOOLS_DIR=/workspace/.alien-tools ./gradlew --no-daemon cleanTest test
```

O primeiro comando inicia Xvfb, define LIBGL_ALWAYS_SOFTWARE=1 e chama ./gradlew --no-daemon runSmokeClient. O mundo é descartável em build/smoke-runtime. As classes atuais de desenvolvimento são carregadas; não foi testada instalação em launcher externo. O atalho é acionado pelo teste com KeyBinding.onTick/evento FML, e os botões são acionados pela automação nos controles reais.

## Falha encontrada e corrigida no teste

A primeira tentativa obteve as imagens, mas travou no encerramento automatizado do servidor integrado. O teste fechava o canal antes do descarregamento do mundo. O ajuste do harness passou a usar a ação vanilla Save and Quit no início do tick do cliente. A repetição seguinte terminou normalmente, com 54 verificações. Nenhuma alteração no código de produção foi necessária. O registro da tentativa interrompida está em build/visual-review/first-attempt-shutdown-hang no workspace.

## Limites

Não implementados: compartilhamento de cosméticos; alteração de skins; importação OBJ/glTF/Blockbench e animações externas; importação por URL/ZIP; editor específico de animação de itens; editor de texturas do sol/lua; pipeline de shaders. O céu/clima é limitado à dimensão 0; Storm não gera raios/trovões próprios.

Não validados: OptiFine, ganhos de FPS/benchmarks comparativos, áudio, multiplayer público/autenticação, outros sistemas e GPUs reais. O limite de 30 FPS desta sessão e os números do HUD não constituem benchmark. Importação cosmética JSON tem testes unitários; o teste gráfico usa acessórios procedurais e importa um panorama PNG.

O arquivo result.txt detalha as 54 verificações, incluindo capturas e guardas; não são 54 funcionalidades diferentes. manifest.json contém os hashes SHA-256 dos PNGs originais.
